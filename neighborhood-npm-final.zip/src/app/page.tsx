'use client'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Search, MapPin, Star, Users, Plus } from 'lucide-react'
import { useState } from 'react'
import Link from 'next/link'

export default function Home() {
  const [searchTerm, setSearchTerm] = useState('')

  // Dados de exemplo para comunidades
  const communities = [
    {
      id: 1,
      title: 'Condomínio Jardim das Flores',
      type: 'Condomínio',
      address: 'Rua das Flores, 123',
      members: 15,
      premium: true
    },
    {
      id: 2,
      title: 'Edifício Aurora',
      type: 'Edifício',
      address: 'Av. Principal, 456',
      members: 8,
      premium: false
    },
    {
      id: 3,
      title: 'Rua das Palmeiras',
      type: 'Rua',
      address: 'Bairro Central',
      members: 22,
      premium: false
    }
  ]

  // Dados de exemplo para avaliações recentes
  const recentReviews = [
    {
      id: 1,
      title: 'Vizinho Barulhento no 3º Andar',
      community: 'Condomínio Jardim das Flores',
      author: 'usuario_exemplo',
      date: '18/04/2025',
      category: 'Barulhento',
      rating: 2
    },
    {
      id: 2,
      title: 'Fumaça de maconha constante',
      community: 'Edifício Aurora',
      author: 'morador_preocupado',
      date: '15/04/2025',
      category: 'Fumante',
      rating: 1
    }
  ]

  const filteredCommunities = communities.filter(community =>
    community.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    community.address.toLowerCase().includes(searchTerm.toLowerCase())
  )

  return (
    <main className="min-h-screen p-4 sm:p-6 md:p-8">
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-blue-500 to-teal-400 text-white rounded-lg p-6 mb-8">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-3xl sm:text-4xl font-bold mb-4">Bem-vindo ao Neighborhood</h1>
          <p className="text-lg mb-6">Avalie seus vizinhos e conecte-se com sua comunidade local.</p>
          
          <div className="relative">
            <input
              type="text"
              placeholder="Buscar comunidades, endereços..."
              className="w-full p-3 pl-10 rounded-lg text-gray-800"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
            <Search className="absolute left-3 top-3.5 h-5 w-5 text-gray-400" />
          </div>
          
          <div className="mt-6 flex flex-wrap gap-4">
            <Button variant="secondary" className="bg-white text-blue-600 hover:bg-gray-100">
              Criar Conta
            </Button>
            <Button variant="outline" className="bg-transparent border-white text-white hover:bg-white/10">
              Saiba Mais
            </Button>
          </div>
        </div>
      </section>

      {/* Comunidades */}
      <section className="mb-12">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold">Comunidades Populares</h2>
          <Button variant="outline" size="sm">
            <Plus className="h-4 w-4 mr-2" />
            Nova Comunidade
          </Button>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredCommunities.map(community => (
            <Card key={community.id} className="p-5 hover:shadow-lg transition-shadow">
              <div className="flex justify-between items-start mb-3">
                <h3 className="font-semibold text-lg">{community.title}</h3>
                {community.premium && (
                  <span className="bg-yellow-100 text-yellow-800 text-xs px-2 py-1 rounded-full">Premium</span>
                )}
              </div>
              <div className="flex items-center text-gray-500 mb-2">
                <MapPin className="h-4 w-4 mr-1" />
                <span className="text-sm">{community.address}</span>
              </div>
              <div className="flex items-center text-gray-500 mb-4">
                <Users className="h-4 w-4 mr-1" />
                <span className="text-sm">{community.members} membros</span>
              </div>
              <Button variant="default" className="w-full">Ver Comunidade</Button>
            </Card>
          ))}
        </div>
      </section>

      {/* Avaliações Recentes */}
      <section className="mb-12">
        <h2 className="text-2xl font-bold mb-6">Avaliações Recentes</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {recentReviews.map(review => (
            <Card key={review.id} className="p-5">
              <h3 className="font-semibold text-lg mb-2">{review.title}</h3>
              <div className="flex justify-between items-center mb-3">
                <span className="text-sm text-gray-500">{review.community}</span>
                <div className="flex items-center">
                  {[...Array(5)].map((_, i) => (
                    <Star 
                      key={i} 
                      className={`h-4 w-4 ${i < review.rating ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'}`} 
                    />
                  ))}
                </div>
              </div>
              <div className="flex justify-between text-sm text-gray-500">
                <span>Por: {review.author}</span>
                <span>{review.date}</span>
              </div>
              <div className="mt-3">
                <span className={`inline-block px-2 py-1 text-xs rounded-full ${
                  review.category === 'Barulhento' 
                    ? 'bg-red-100 text-red-800' 
                    : 'bg-purple-100 text-purple-800'
                }`}>
                  {review.category}
                </span>
              </div>
            </Card>
          ))}
        </div>
      </section>

      {/* Planos Premium */}
      <section className="bg-gray-50 rounded-lg p-6">
        <div className="text-center mb-8">
          <h2 className="text-2xl font-bold mb-2">Planos Premium</h2>
          <p className="text-gray-600">Acesso a recursos exclusivos e criação de comunidades</p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <Card className="p-6 border-t-4 border-blue-500">
            <h3 className="text-xl font-bold mb-4 text-center">Básico</h3>
            <p className="text-3xl font-bold text-center mb-6">Grátis</p>
            <ul className="space-y-3 mb-8">
              <li className="flex items-start">
                <span className="text-green-500 mr-2">✓</span>
                <span>Avaliações básicas de vizinhos</span>
              </li>
              <li className="flex items-start">
                <span className="text-green-500 mr-2">✓</span>
                <span>Participação em comunidades</span>
              </li>
              <li className="flex items-start text-gray-400">
                <span className="mr-2">✗</span>
                <span>Criação de comunidades</span>
              </li>
              <li className="flex items-start text-gray-400">
                <span className="mr-2">✗</span>
                <span>Avaliações detalhadas</span>
              </li>
            </ul>
            <Button variant="outline" className="w-full">Começar Agora</Button>
          </Card>
          
          <Card className="p-6 border-t-4 border-purple-500 shadow-lg">
            <div className="absolute -top-3 left-0 right-0 flex justify-center">
              <span className="bg-purple-500 text-white text-xs px-3 py-1 rounded-full">Popular</span>
            </div>
            <h3 className="text-xl font-bold mb-4 text-center">Plus</h3>
            <p className="text-3xl font-bold text-center mb-6">R$9,90<span className="text-sm font-normal">/mês</span></p>
            <ul className="space-y-3 mb-8">
              <li className="flex items-start">
                <span className="text-green-500 mr-2">✓</span>
                <span>Tudo do plano Básico</span>
              </li>
              <li className="flex items-start">
                <span className="text-green-500 mr-2">✓</span>
                <span>Criação de comunidades</span>
              </li>
              <li className="flex items-start">
                <span className="text-green-500 mr-2">✓</span>
                <span>Avaliações detalhadas</span>
              </li>
              <li className="flex items-start text-gray-400">
                <span className="mr-2">✗</span>
                <span>Gestão de múltiplas comunidades</span>
              </li>
            </ul>
            <Button className="w-full">Assinar Agora</Button>
          </Card>
          
          <Card className="p-6 border-t-4 border-yellow-500">
            <h3 className="text-xl font-bold mb-4 text-center">Premium</h3>
            <p className="text-3xl font-bold text-center mb-6">R$19,90<span className="text-sm font-normal">/mês</span></p>
            <ul className="space-y-3 mb-8">
              <li className="flex items-start">
                <span className="text-green-500 mr-2">✓</span>
                <span>Tudo do plano Plus</span>
              </li>
              <li className="flex items-start">
                <span className="text-green-500 mr-2">✓</span>
                <span>Gestão de múltiplas comunidades</span>
              </li>
              <li className="flex items-start">
                <span className="text-green-500 mr-2">✓</span>
                <span>Estatísticas avançadas</span>
              </li>
              <li className="flex items-start">
                <span className="text-green-500 mr-2">✓</span>
                <span>Suporte prioritário</span>
              </li>
            </ul>
            <Button variant="outline" className="w-full">Assinar Agora</Button>
          </Card>
        </div>
      </section>
    </main>
  )
}

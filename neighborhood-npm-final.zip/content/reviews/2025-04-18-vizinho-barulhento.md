---
title: Vizinho Barulhento no 3º Andar
community: Condomínio Jardim das Flores
author: usuario_exemplo
date: 2025-04-18T08:30:00.000Z
category: Barulhento
description: Vizinho faz festas até tarde da noite nos finais de semana, com música alta e muitas pessoas.
rating: 2
anonymous: false
verified: true
---

O morador do apartamento 302 frequentemente realiza festas aos finais de semana que vão até depois das 2h da manhã. A música é extremamente alta e há muitas pessoas conversando na varanda, o que perturba o sono de todos os vizinhos. Já foram feitas várias reclamações na administração, mas o problema persiste.

---
username: usuario_exemplo
fullName: João da Silva
email: joao@exemplo.com
bio: Morador do Condomínio Jardim das Flores há 5 anos. Gosto de tranquilidade e respeito aos vizinhos.
memberSince: 2023-01-15T10:00:00.000Z
premium: true
communities:
  - Condomínio Jardim das Flores
reviewsCount: 3
---

Perfil de usuário exemplo para demonstração do sistema Neighborhood.
